% --- ข้อมูล (Inputs) ---
Vin = 12;                % แรงดัน (V)
Inl = 2079.939897;       % กระแสเดินเปล่า (mA หรือหน่วยตามตาราง)
T_st = 0.01712;          % Stall Torque
w_nl_rpm = 2500;         %

% ค่า kt จากตาราง (ใช้เพื่อหา Stall Current โดยประมาณ)
kt = 0.000000332427;     
I_st = T_st / kt;        % คำนวณ Stall Current

% --- การคำนวณสร้างกราฟ ---
% 1. สร้างแกน Torque (แกน X)
Torque = linspace(0, T_st, 100);

% 2. กราฟ Speed (เส้นตรงลดลง)
% สูตร: Speed ที่จุดใดๆ = Speedเริ่มต้น * (1 - สัดส่วนแรงบิด)
Speed_RPM = w_nl_rpm * (1 - (Torque / T_st));

% 3. กราฟ Current (เส้นตรงเพิ่มขึ้น)
Current = Inl + ((I_st - Inl) / T_st) .* Torque;

% 4. กราฟ Power Output (ภูเขา)
% *สำคัญ* ต้องแปลง RPM เป็น Rad/s ก่อนคูณ Torque เพื่อให้ได้หน่วย Watt
w_rad_s = Speed_RPM * (2 * pi / 60); 
PowerOut = Torque .* w_rad_s; 

% 5. กราฟ Efficiency
PowerIn = Vin .* Current; % (ระวังหน่วย Current ถ้าในตารางไม่ใช่ Ampere ค่า Eff จะเพี้ยน แต่รูปทรงจะถูก)
Efficiency = (PowerOut ./ PowerIn) * 100;

% --- พลอตกราฟ (Plotting) ---
figure('Name', 'DC Motor Performance');

% แกนซ้าย (Speed & Efficiency)
yyaxis left
plot(Torque, Speed_RPM, 'b-', 'LineWidth', 2); hold on;
% ปรับสเกล Efficiency ให้โชว์สวยๆ เทียบกับ Speed
plot(Torque, Efficiency * (max(Speed_RPM)/100), 'g-', 'LineWidth', 2); 
ylabel('Speed (RPM)');
xlabel('Torque');

% แกนขวา (Current & Power)
yyaxis right
plot(Torque, Current, 'r-', 'LineWidth', 2); hold on;
% ปรับสเกล Power ให้โชว์สวยๆ เทียบกับ Current
plot(Torque, PowerOut * (max(Current)/max(PowerOut)), 'y-', 'LineWidth', 2); 
ylabel('Current / Power');

title(['DC Motor Curve @ ' num2str(w_nl_rpm) ' RPM']);
legend('Speed (RPM)', 'Efficiency', 'Current', 'Power Out');
grid on;